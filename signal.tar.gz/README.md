This tarball contains five intermittent signals injected into noise.
Each signal is injected into both H1 and L1, and therefore has a pair
of files. So, e.g. the first signal is is the files:
signal1_H1.txt and signal1_L1.txt
and so on. The files are in the form of heterodyned data and therefore
have three columns:
the GPS timestamp
the real part of the data
the imag part of the data
 

def logaddexp( x, y ):
#   Input 2 log values to be summed. Output double precision
#   output which is the sum of the input
	z = log(exp(x - y) + 1) + y;
	return z





